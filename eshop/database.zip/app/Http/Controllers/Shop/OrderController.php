<?php

namespace App\Http\Controllers\Shop;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function placeOrder()
    {
        $user = Auth::user();

        if (!$user || !$user->userInfo) {
            return redirect()->route('cart.customer')->with('error', 'Missing user info');
        }

        $cartData = app(CartController::class)->getCartData();
        $cartItems = $cartData['cartItems'];

        if ($cartItems->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Cart is empty');
        }

        $shippingMethodId = session('checkout.shipping_method_id');
        $paymentMethodId = session('checkout.payment_method_id');

        if (!$shippingMethodId || !$paymentMethodId) {
            return redirect()->route('cart.shipping')->with('error', 'Missing shipping/payment');
        }

        $address = $user->userInfo->addresses()->first();

        DB::transaction(function () use ($user, $cartItems, $shippingMethodId, $paymentMethodId, $address) {

            $order = Order::create([
                'user_info_id' => $user->userInfo->id,
                'shipping_address_id' => $address->id,
                'billing_address_id' => $address->id,
                'shipping_method_id' => $shippingMethodId,
                'state' => 'Created',
            ]);

            $total = 0;

            foreach ($cartItems as $item) {
                $price = data_get($item, 'price', data_get($item, 'product.price', 0));
                $quantity = data_get($item, 'quantity', 1);

                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item->product_id ?? $item['product_id'],
                    'quantity' => $quantity,
                    'item_price' => $price,
                ]);

                $total += $price * $quantity;
            }

            $order->update(['total_price' => $total]);

            Payment::create([
                'order_id' => $order->id,
                'payment_method_id' => $paymentMethodId,
                'amount' => $total,
                'state' => 'Unpaid',
            ]);

            if (Auth::check()) {
                $cart = Cart::where('user_id', $user->id)->first();
                if ($cart) {
                    $cart->cartItems()->delete();
                    $cart->delete();
                }
            } else {
                session()->forget('cart');
            }
        });

        return redirect()->route('cart.index')->with('success', 'Order created!');
    }
}