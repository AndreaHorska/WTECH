<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Lucky Quacky @yield('title', 'Eshop')</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    @vite([
        'resources/css/variables.css',
        'resources/css/user_style.css',
        'resources/js/app.js'
    ])

    @stack('styles')
    
    @stack('scripts')
</head>
<body>

    @yield('content')

</body>
</html>
