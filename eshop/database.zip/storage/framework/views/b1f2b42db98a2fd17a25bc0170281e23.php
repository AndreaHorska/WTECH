<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/product_card.css',
        'resources/css/products.css'
    ]); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/products.js']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/filter.js']); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>

<main class="main-content">
    <aside class="sidebar">
        <form method="GET" action="<?php echo e(route('products.index')); ?>" id="filterForm">
            
            <?php if(request('main')): ?>
                <input type="hidden" name="main" id="mainCategory" value="<?php echo e(request('main')); ?>">
            <?php endif; ?>
            <input type="hidden" name="sort" value="<?php echo e(request('sort', 'recommended')); ?>">
            <input type="hidden" name="per_page" value="<?php echo e(request('per_page', 10)); ?>">
            <input type="hidden" name="query" value="<?php echo e(request('query', '')); ?>">
            <input type="hidden" name="rating" id="ratingInput" value="<?php echo e(request('rating', 1)); ?>">

            <h2 class="filter-title">Filter</h2>

            <section class="filter-section">
                <h3 class="filter-section-title">Price</h3>
                <div class="slider" id="slider">
                    <div class="track"></div>
                    <div class="progress" id="progress"></div>
                    <div class="handle" id="minHandle"></div>
                    <div class="handle" id="maxHandle"></div>
                </div>
                <div class="price-inputs">
                    <label for="minInput" class="visually-hidden">Minimum Price</label>
                    <input type="number" value="<?php echo e(request('min_price', $dbMinPrice)); ?>" min="<?php echo e($dbMinPrice); ?>" max="<?php echo e($dbMaxPrice); ?>" class="price-input" id="minInput" name="min_price">
                    <label for="maxInput" class="visually-hidden">Maximum Price</label>
                    <input type="number" value="<?php echo e(request('max_price', $dbMaxPrice )); ?>" min="<?php echo e($dbMinPrice); ?>" max="<?php echo e($dbMaxPrice); ?>" class="price-input" id="maxInput" name="max_price">
                </div>
            </section>

            <section class="filter-section">
                <h3 class="filter-section-title">Star Rating (min.)</h3>
                <div class="stars-filter" id="starRating">
                    <svg style="display:none;">
                        <symbol id="star-icon" viewBox="0 0 24 24">
                            <path d="M12 2l3 7 7 .5-5.5 4.5 1.5 7-6-4-6 4 1.5-7L2 9.5 9 9z"/>
                        </symbol>
                    </svg>

                    <div class="stars-filter">
                        <svg class="star-filter" data-value="1"><use href="#star-icon"></use></svg>
                        <svg class="star-filter" data-value="2"><use href="#star-icon"></use></svg>
                        <svg class="star-filter" data-value="3"><use href="#star-icon"></use></svg>
                        <svg class="star-filter" data-value="4"><use href="#star-icon"></use></svg>
                        <svg class="star-filter" data-value="5"><use href="#star-icon"></use></svg>
                    </div>
                </div>
            </section>

            <section class="filter-section">
                <h3 class="filter-section-title">Accessories</h3>

                <?php $__currentLoopData = $categoryTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accessories-filter">
                        <h4 class="filter-subheading"><?php echo e($type->name); ?></h4>

                        <div class="checkbox-group">
                            <?php $__currentLoopData = $type->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="categories[]" value="<?php echo e($category->slug); ?>"
                                        <?php if(in_array($category->slug, request('categories', []))): echo 'checked'; endif; ?>>
                                    <span><?php echo e($category->name); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <button class="filter-button">Filter</button>
        </form>
    </aside>

    <section class="product-section">

        <div class="sort-header">
            <div class="tabs">
                <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['sort' => 'recommended', 'per_page' => $perPage]))); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tab', 'active' => $sort === 'recommended']); ?>">
                    Recommended
                </a>

                <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['sort' => 'popular', 'per_page' => $perPage]))); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tab', 'active' => $sort === 'popular']); ?>">
                    Most Popular
                </a>

                <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['sort' => 'price_asc', 'per_page' => $perPage]))); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tab', 'active' => $sort === 'price_asc']); ?>">
                    Price: Low to High
                </a>

                <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['sort' => 'price_desc', 'per_page' => $perPage]))); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tab', 'active' => $sort === 'price_desc']); ?>">
                    Price: High to Low
                </a>
            </div>

            <div class="items-per-page">
                <div class="items-label">Items per page</div>
                <div class="items-options">
                    <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['sort' => $sort, 'per_page' => 10]))); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $perPage === 10]); ?>">10</a> /
                    <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['sort' => $sort, 'per_page' => 25]))); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $perPage === 25]); ?>">25</a> /
                    <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['sort' => $sort, 'per_page' => 50]))); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $perPage === 50]); ?>">50</a> /
                    <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['sort' => $sort, 'per_page' => 100]))); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $perPage === 100]); ?>">100</a>
                </div>
            </div>
        </div>

        <div class="product-grid">

            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $image = $product->images->first();
                ?>

                <article class="product-card" data-href="<?php echo e(route('product.show', $product->id)); ?>" data-rating="<?php echo e($product->rating); ?>" data-reviews="<?php echo e($product->review_count); ?>">

                    <img src="<?php echo e($image ? asset($image->image_path) : asset('image/duck.png')); ?>" alt="<?php echo e($product->name); ?>" class="product-image">

                    <div class="product-rating" aria-label="Rated <?php echo e($product->rating); ?> out of 5 stars">
                        <div class="stars" aria-hidden="true">
                            <div class="stars-base">★★★★★</div>
                            <div class="stars-fill" style="width: <?php echo e(($product->rating / 5) * 100); ?>%">★★★★★</div>
                        </div>

                        <p class="rating-text">
                            <span class="rating-number">
                                <?php echo e(number_format($product->rating, 1, ',', ' ')); ?>

                            </span>
                            <span class="rating-count">
                                <?php echo e($product->review_count); ?>x
                            </span>
                        </p>
                    </div>

                    <h3 class="product-title"><?php echo e($product->name); ?></h3>

                    <p class="product-price">
                        <?php echo e(number_format($product->price, 2, ',', ' ')); ?>€
                    </p>

                    <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="quantity" value="1">
                        <button class="add-to-cart" type="submit" aria-label="Add product to cart">
                            <svg class="cart-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="9" cy="21" r="1"></circle>
                                <circle cx="18" cy="21" r="1"></circle>
                                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h7.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                            </svg>
                            <span>Add to cart</span>
                        </button>
                    </form>
                </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No products found.</p>
            <?php endif; ?>

        </div>

        <div class="pagination-wrapper">
            <?php echo e($products->links('pagination.custom')); ?>

        </div>

    </section>


</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/products.blade.php ENDPATH**/ ?>