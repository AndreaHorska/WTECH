<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Lucky Quacky <?php echo $__env->yieldContent('title', 'Eshop'); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/variables.css',
        'resources/css/user_style.css',
        'resources/js/app.js'
    ]); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/layouts/formular.blade.php ENDPATH**/ ?>