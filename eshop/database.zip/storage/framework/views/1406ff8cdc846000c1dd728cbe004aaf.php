<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/cart.css',
    ]); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/cart_shipping.js']); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', 'Cart - Shipping Info'); ?>

<?php $__env->startSection('content'); ?>

    <?php
        $selectedDelivery = session()->hasOldInput()
            ? old('delivery')
            : session('checkout.shipping_method_id');

        $selectedPayment = session()->hasOldInput()
            ? old('payment')
            : session('checkout.payment_method_id');

        $shippingFee = $selectedShipping?->fee ?? 0;
        $paymentFee = $selectedPayment?->fee ?? 0;

        $total = $subtotal + $shippingFee + $paymentFee
    ?>

    <main class="cart-page">
        <nav class="checkout-steps" aria-label="Checkout steps">
            <ol class="checkout-steps-list">
                <li class="checkout-step">
                    <span class="checkout-step-circle">1</span>
                    <span class="checkout-step-label">Cart</span>
                </li>
                <li class="checkout-step active">
                    <span class="checkout-step-circle">2</span>
                    <span class="checkout-step-label">Shipping &amp; Payment</span>
                </li>
                <li class="checkout-step">
                    <span class="checkout-step-circle">3</span>
                    <span class="checkout-step-label">Customer Info</span>
                </li>
            </ol>
        </nav>

        <section class="cart-shipping-layout" aria-labelledby="cart-heading"
                 data-subtotal="<?php echo e($subtotal); ?>">

            <div class="checkout-options">
                <form method="POST" action="<?php echo e(route('cart.shipping.save')); ?>">
                    <?php echo csrf_field(); ?>

                    <h2 class="form-section-title">Select delivery method</h2>
                    <div class="options-group">
                        <?php $__currentLoopData = $shippingMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="option-item">
                                <input type="radio" name="delivery" value="<?php echo e($method->id); ?>" data-fee="<?php echo e($method->fee); ?>"
                                    <?php if($selectedDelivery == $method->id): echo 'checked'; endif; ?>>
                                <span class="option-icon"><?php echo e($method->icon); ?></span>
                                <span class="option-name"><?php echo e($method->name); ?></span>
                                <span class="option-price"><?php echo e($method->fee > 0 ? number_format($method->fee, 2, ',', ' ') . ' €' : 'free'); ?></span>
                                <span class="option-eta"><?php echo e($method->eta_text); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php $__errorArgs = ['delivery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="form-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <h2 class="form-section-title">Select payment method</h2>
                    <div class="options-group">
                        <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="option-item">
                                <input
                                    type="radio" name="payment" value="<?php echo e($method->id); ?>" data-fee="<?php echo e($method->fee); ?>"
                                    <?php if($selectedPayment == $method->id): echo 'checked'; endif; ?>>
                                <span class="option-icon"><?php echo e($method->icon); ?></span>
                                <span class="option-name"><?php echo e($method->name); ?></span>
                                <span class="option-price"><?php echo e($method->fee > 0 ? number_format($method->fee, 2, ',', ' ') . ' €' : 'free'); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="form-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="form-buttons">
                        <a href="<?php echo e(route('cart.index')); ?>" class="back-button">Back</a>
                        <button type="submit" class="continue-button">Continue</button>
                    </div>
                </form>
            </div>

            <section class="cart-main">

                <ul class="cart-list">
                    <h2 id="summary-heading" class="order-summary-title">Order summary</h2>

                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $product = data_get($item, 'product');
                            $productId = data_get($item, 'product_id', data_get($product, 'id'));
                            $name = data_get($item, 'name', data_get($product, 'name', 'Product'));
                            $price = (float) data_get($item, 'price', data_get($product, 'price', 0));
                            $quantity = (int) data_get($item, 'quantity', 1);
                            $lineTotal = $price * $quantity;
                            $image = $product->images->first();
                        ?>

                        <li class="summary-item">
                            <a href="<?php echo e(route('product.show', $productId)); ?>">
                                <img src="<?php echo e($image ? asset($image->image_path) : asset('image/duck.png')); ?>" alt="<?php echo e($name); ?>" class="cart-item-image">
                            </a>

                            <div class="summary-item-details">
                                <a href="<?php echo e($productId ? route('product.show', $productId) : '#'); ?>" class="summary-item-title">
                                    <?php echo e($name); ?>

                                </a>
                                <span class="summary-product-quantity"><?php echo e($quantity); ?>×</span>
                            </div>

                            <p class="summary-item-price"><?php echo e(number_format($lineTotal, 2, ',', ' ')); ?> €</p>


                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

                <hr class="summary-divider">

                <dl class="summary-prices">
                    <dt>Subtotal</dt>
                    <dd id="subtotalPrice"><?php echo e(number_format($subtotal, 2, ',', ' ')); ?> €</dd>

                    <dt>Delivery</dt>
                    <dd id="deliveryPrice"><?php echo e(number_format($shippingFee, 2, ',', ' ')); ?> €</dd>

                    <dt>Payment</dt>
                    <dd id="paymentPrice"><?php echo e(number_format($paymentFee, 2, ',', ' ')); ?> €</dd>
                </dl>

                <hr class="summary-divider">

                <dl class="summary-totals">
                    <dt>Total</dt>
                    <dd id="totalPrice"><?php echo e(number_format($total, 2, ',', ' ')); ?> €</dd>
                </dl>

            </section>
        </section>
    </main>
<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/cart-shipping.blade.php ENDPATH**/ ?>