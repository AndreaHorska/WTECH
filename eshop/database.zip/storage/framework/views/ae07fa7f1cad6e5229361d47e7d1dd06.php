<?php if($paginator->hasPages()): ?>
    <nav class="pagination" aria-label="Pagination">

        
        <?php if($paginator->onFirstPage()): ?>
            <span class="page-link" aria-disabled="true">&lt;</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page-link">&lt;</a>
        <?php endif; ?>

        <?php
            $current = $paginator->currentPage();
            $last = $paginator->lastPage();

            $start = max($current - 1, 1);
            $end = min($current + 1, $last);
        ?>

        
        <?php if($start > 1): ?>
            <a href="<?php echo e($paginator->url(1)); ?>"
               class="page-link <?php echo e($current === 1 ? 'active' : ''); ?>">
                1
            </a>
        <?php endif; ?>

        
        <?php if($start > 2): ?>
            <span class="page-ellipsis">...</span>
        <?php endif; ?>

        
        <?php for($page = $start; $page <= $end; $page++): ?>
            <a href="<?php echo e($paginator->url($page)); ?>"
               class="page-link <?php echo e($page === $current ? 'active' : ''); ?>"
               <?php if($page === $current): ?> aria-current="page" <?php endif; ?>>
                <?php echo e($page); ?>

            </a>
        <?php endfor; ?>

        
        <?php if($end < $last - 1): ?>
            <span class="page-ellipsis">...</span>
        <?php endif; ?>

        
        <?php if($end < $last): ?>
            <a href="<?php echo e($paginator->url($last)); ?>"
               class="page-link <?php echo e($current === $last ? 'active' : ''); ?>">
                <?php echo e($last); ?>

            </a>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page-link">&gt;</a>
        <?php else: ?>
            <span class="page-link" aria-disabled="true">&gt;</span>
        <?php endif; ?>

    </nav>
<?php endif; ?>
<?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/pagination/custom.blade.php ENDPATH**/ ?>