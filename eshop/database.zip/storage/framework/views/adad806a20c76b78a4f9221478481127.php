<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/style.css',
        'resources/css/admin_style.css'
    ]); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', '- Admin-panel'); ?>

<?php $__env->startSection('content'); ?>
<main class="main container mt-4">

  <div class="d-flex justify-content-between align-items-center">
    <h2>Admin - Products</h2>
    <a class="btn btn-primary"
      href="<?php echo e(route('admin.product.add')); ?>">+ Add product</a>
  </div>

  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Image</th>
          <th>Name</th>
          <th>Price</th>
          <th>Category</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        <?php $__currentLoopData = $products->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $image = $product->images->first(); ?>
          <tr>
            <td data-label="ID"><?php echo e($product->id); ?></td>
            <td data-label="Image">
              <img src="<?php echo e(asset($image?->image_path ?? 'image/duck.png')); ?>" width="50">
            </td>
            <td data-label="Name"><?php echo e($product->name); ?></td>
            <td data-label="Price"><?php echo e(number_format($product->price, 2, ',', ' ')); ?>€</td>
            <td data-label="Category"><?php echo e($product->categories->pluck('name')->join(', ')); ?></td>
            <td data-label="Action">
                <div class="admin-buttons">
                    <a class="btn btn-sm btn-warning" href="<?php echo e(route('admin.product.edit', $product->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('admin.product.destroy', $product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Really want to delete?')">Delete</button>
                    </form>
                </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
  </div>

</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/admin-panel.blade.php ENDPATH**/ ?>