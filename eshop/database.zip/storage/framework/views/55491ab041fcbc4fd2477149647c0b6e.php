<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/product_card.css',
        'resources/css/style.css'
    ]); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/products.js']); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', '- homepage'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
<section class="top-news">
    <a class="about_us" href="<?php echo e(route('products.index')); ?>" >
        <h2 class="about-title">Lucky Quacky</h2>
        <p class="about-text">
            Fun, stylish and unique duck stickers for everyone
        </p>
        <p class="all_categories">See every single one of our wonderful ducks</p>
    </a>
    <div class="sales">
        <span class="sale-big">-50%</span>
        <span class="sale-text">SALE</span>
    </div>
</section>

<section class="category-box">
    <div class="category" onclick="location.href='<?php echo e(route('products.index', ['main' => 'funny'])); ?>'">Funny</div>
    <div class="category" onclick="location.href='<?php echo e(route('products.index', ['main' => 'luxurious'])); ?>'">Luxurious</div>
    <div class="category" onclick="location.href='<?php echo e(route('products.index', ['main' => 'seasonal'])); ?>'">Seasonal</div></section>

<section class="products-box">
    <h2 class="mb-4 h3">New Arrivals</h2>
    <div class="product-grid">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $image = $product->images->first(); ?>
            <article class="product-card" data-href="<?php echo e(route('product.show', $product->id)); ?>" data-rating="<?php echo e($product->rating); ?>" data-reviews="<?php echo e($product->review_count); ?>">
                <img src="<?php echo e($image ? asset($image->image_path) : asset('image/duck.png')); ?>" alt="<?php echo e($product->name); ?>" class="product-image">
                <div class="product-rating" aria-label="Rated <?php echo e($product->rating); ?> out of 5 stars">
                    <div class="stars" aria-hidden="true">
                        <div class="stars-base">★★★★★</div>
                        <div class="stars-fill" style="width: <?php echo e(($product->rating / 5) * 100); ?>%">★★★★★</div>
                    </div>
                    <p class="rating-text">
                        <span class="rating-number"><?php echo e(number_format($product->rating, 1, ',', ' ')); ?></span>
                        <span class="rating-count"><?php echo e($product->review_count); ?>x</span>
                    </p>
                </div>
                <h3 class="product-title"><?php echo e($product->name); ?></h3>
                <p class="product-price"><?php echo e(number_format($product->price, 2, ',', ' ')); ?>€</p>
                <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                    <input type="hidden" name="quantity" value="1">
                    <button class="add-to-cart" type="submit" aria-label="Add product to cart">
                        <svg class="cart-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="18" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h7.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                        <span>Add to cart</span>
                    </button>
                </form>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/index.blade.php ENDPATH**/ ?>