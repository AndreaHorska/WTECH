<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/cart.css',
    ]); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/cart.js']); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('content'); ?>

    <main class="cart-page">
        <?php if($cartItems->isEmpty()): ?>
            <div class="cart-empty-page">
                <div class="cart-empty">
                    <p>Your cart is empty.</p>
                    <a href="<?php echo e(url('/')); ?>" class="continue-button">Back to shop</a>
                </div>
            </div>

        <?php else: ?>
            <nav class="checkout-steps" aria-label="Checkout steps">
                <ol class="checkout-steps-list">
                    <li class="checkout-step active">
                        <span class="checkout-step-circle">1</span>
                        <span class="checkout-step-label">Cart</span>
                    </li>
                    <li class="checkout-step">
                        <span class="checkout-step-circle">2</span>
                        <span class="checkout-step-label">Shipping &amp; Payment</span>
                    </li>
                    <li class="checkout-step">
                        <span class="checkout-step-circle">3</span>
                        <span class="checkout-step-label">Customer Info</span>
                    </li>
                </ol>
            </nav>

            <section class="cart-layout" aria-label="Cart items">

                <section class="cart-main">
                    <ul class="cart-list">
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $product = data_get($item, 'product');
                                $productId = data_get($item, 'product_id', data_get($product, 'id'));
                                $name = data_get($item, 'name', data_get($product, 'name', 'Product'));
                                $price = (float) data_get($item, 'price', data_get($product, 'price', 0));
                                $quantity = (int) data_get($item, 'quantity', 1);
                                $lineTotal = $price * $quantity;

                                $image = $product->images->first();

                                $inStock = (int) data_get($product, 'quantity', 0) >= $quantity;
                            ?>

                            <li class="cart-item">
                                <a href="<?php echo e(route('product.show', $productId)); ?>">
                                    <img src="<?php echo e($image ? asset($image->image_path) : asset('image/duck.png')); ?>" alt="<?php echo e($name); ?>" class="cart-item-image">
                                </a>

                                <div class="cart-item-description">
                                    <a href="<?php echo e($productId ? route('product.show', $productId) : '#'); ?>" class="cart-item-title">
                                        <?php echo e($name); ?>

                                    </a>
                                    <p class="cart-item-info"><?php echo e(data_get($product, 'description', '')); ?></p>
                                </div>

                                <p class="stock-status <?php echo e($inStock ? 'in-stock' : 'out-of-stock'); ?>">
                                    <?php if($inStock): ?>
                                        <svg class="stock-icon" viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M20 6L9 17L4 12"/>
                                        </svg>
                                        <span>In stock</span>
                                    <?php else: ?>
                                        <svg class="stock-icon" viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M18 6L6 18M6 6l12 12"/>
                                        </svg>
                                        <span>Out of stock</span>
                                    <?php endif; ?>
                                </p>

                                <form action="<?php echo e(route('cart.update', $productId)); ?>" method="POST" class="quantity-picker">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>

                                    <button type="button" class="quantity-button" aria-label="Decrease quantity">
                                        <svg class="quantity-icon" viewBox="0 0 24 24"><path d="M5 12h14"/></svg>
                                    </button>

                                    <input type="number" name="quantity" value="<?php echo e($quantity); ?>" min="1" max="<?php echo e(data_get($product, 'quantity', 1)); ?>" class="quantity-input">

                                    <button type="button" class="quantity-button" aria-label="Increase quantity">
                                        <svg class="quantity-icon" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                                    </button>
                                </form>

                                <p class="cart-item-unit-price"><?php echo e(number_format($price, 2, ',', ' ')); ?> € / pcs</p>
                                <p class="cart-item-total-price"><?php echo e(number_format($lineTotal, 2, ',', ' ')); ?> €</p>

                                <form action="<?php echo e(route('cart.remove', $productId)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="remove-button" aria-label="Remove Product from Cart">
                                        <svg class="remove-icon" viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M6 6l12 12"></path>
                                            <path d="M18 6L6 18"></path>
                                        </svg>
                                    </button>
                                </form>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </section>

                <?php
                    $hasOutOfStock = $cartItems->contains(function ($item) {
                        $product = data_get($item, 'product');
                        $quantity = (int) data_get($item, 'quantity', 1);
                        return (int) data_get($product, 'quantity', 0) < $quantity;
                    });
                ?>

                <aside class="order-summary" aria-labelledby="summary-heading">
                    <h2 id="summary-heading" class="order-summary-title">Order summary</h2>

                    <div class="duck-note">
                        <span class="duck-note-icon">
                            <svg viewBox="0 0 680 400" xmlns="http://www.w3.org/2000/svg">
                                <ellipse cx="330" cy="300" rx="110" ry="80" fill="currentColor"/>
                                <ellipse cx="220" cy="280" rx="40" ry="30" fill="currentColor"/>
                                <circle cx="400" cy="195" r="55" fill="currentColor"/>
                                <rect x="448" y="188" width="45" height="20" rx="10" fill="currentColor"/>
                                <circle cx="418" cy="183" r="10" fill="white"/>
                                <path d="M235 310 Q310 270 400 305" fill="none" stroke="white" stroke-width="10" stroke-linecap="round"/>
                                <rect x="360" y="235" width="55" height="40" fill="currentColor"/>
                            </svg>
                        </span>

                        <div>
                            <div class="duck-note-title">Your ducks are almost home</div>
                            <div class="duck-note-text">Just one more step</div>
                        </div>
                    </div>

                    <hr class="summary-divider">

                    <dl class="summary-totals">
                        <dt>Total</dt>
                        <dd><?php echo e(number_format($subtotal, 2, ',', ' ')); ?> €</dd>
                    </dl>

                    <div class="order-summary_buttons">
                        <a href="<?php echo e(url('/')); ?>" class="back-button">Back</a>
                        <?php if($hasOutOfStock): ?>
                            <span class="continue-button disabled" style="opacity:0.5; cursor:not-allowed;" title="Remove out of stock items to continue">Continue</span>
                        <?php else: ?>
                            <a href="<?php echo e(route('cart.shipping')); ?>" class="continue-button">Continue</a>
                        <?php endif; ?>
                    </div>
                </aside>
            </section>
        <?php endif; ?>
    </main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/cart.blade.php ENDPATH**/ ?>