<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/style.css',
        'resources/css/product_card.css'
    ]); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/products.js']); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', '- product detail'); ?>

<?php $__env->startSection('content'); ?>
<main class="main_product">
<section class="product_section">

    <div class="product_gallery">
        <div class="thumbnails">
            <?php $__empty_1 = true; $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <img class="thumb <?php echo e($loop->first ? 'active' : ''); ?>" src="<?php echo e(asset($image->image_path)); ?>" alt="thumb<?php echo e($loop->iteration); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <img class="thumb active" src="<?php echo e(asset('image/duck.png')); ?>" alt="thumb1">
            <?php endif; ?>
        </div>
        <div class="main_product_box">
            <img id="mainImage" src="<?php echo e(asset($product->images->first()?->image_path ?? 'image/duck.png')); ?>" alt="main image">
        </div>
    </div>

    <div class="product_info">
      <h1><?php echo e($product->name); ?></h1>
      <div class="product-rating" aria-label="Rated <?php echo e($product->rating); ?> out of 5 stars">
            <div class="stars" aria-hidden="true">
                <div class="stars-base">★★★★★</div>
                <div class="stars-fill" style="width: <?php echo e(($product->rating / 5) * 100); ?>%">★★★★★</div>
            </div>
            <p class="rating-text">
                <span class="rating-number"><?php echo e(number_format($product->rating, 1, ',', ' ')); ?></span>
                <span class="rating-count"><?php echo e($product->review_count); ?>x</span>
            </p>
      </div>
      <div class="description">
        <?php echo e($product->description); ?>

      </div>

      <form action="<?php echo e(route('cart.add')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
        <div class="quantity_control">
            <p>Quantity:</p>
            <input type="number" name="quantity" value="1" min="1" id="quantityInput">
        </div>
        <div class="stock-info mb-2">
            <?php if($product->quantity > 5): ?>
                <span class="text-success fw-bold fs-6 d-flex align-items-center">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="me-2">
                        <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    In stock &gt; 5
                </span>
            <?php elseif($product->quantity > 0): ?>
                <span class="text-warning fw-bold fs-6">
                    Only <?php echo e($product->quantity); ?> left!
                </span>
            <?php else: ?>
                <span class="text-danger fw-bold fs-6">
                    Out of stock
                </span>
            <?php endif; ?>
        </div>
        <h1><?php echo e(number_format($product->price, 2, ',', ' ')); ?>€</h1>
        <button type="submit" class="btn btn-warning px-5" <?php echo e($product->quantity == 0 ? 'disabled' : ''); ?>>Add to cart</button>
    </form>
    </div>

  </section>



<section class="specification">

  <div class="left_spec">
    <h2>Specification</h2>
    <table class="spec-table">
      <tr>
        <td>Material</td>
        <td><?php echo e($product->material); ?></td>
      </tr>
      <tr>
        <td>Size</td>
        <td><?php echo e($product->size); ?></td>
      </tr>
      <tr>
        <td>Weight</td>
        <td><?php echo e($product->weight); ?></td>
      </tr>
      <tr>
        <td>Age</td>
        <td><?php echo e($product->age); ?></td>
      </tr>
      <tr>
        <td>Country of origin</td>
        <td><?php echo e($product->country_of_origin); ?></td>
      </tr>
    </table>
  </div>

  <div class="right_spec">
    <h2>Customer Review</h2>
    <p class="text-muted small">How would you rate this product?</p>

    <form action="#" method="POST" class="review-form">
        <div class="star-rating-input mb-3">
            <input type="radio" id="star5" name="rating" value="5" required>
            <label for="star5" title="5 stars">★</label>

            <input type="radio" id="star4" name="rating" value="4">
            <label for="star4" title="4 stars">★</label>

            <input type="radio" id="star3" name="rating" value="3">
            <label for="star3" title="3 stars">★</label>

            <input type="radio" id="star2" name="rating" value="2">
            <label for="star2" title="2 stars">★</label>

            <input type="radio" id="star1" name="rating" value="1">
            <label for="star1" title="1 star">★</label>
        </div>

        <button type="button" class="btn btn-dark w-100 fw-bold">Add review</button>
    </form>

  </div>
</section>

<section class="related_products">
  <h2 class="mb-4 h3">Similar Products</h2>

  <div class="product-grid">

        <?php $__currentLoopData = $similar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $image = $item->images->first(); ?>
            <article class="product-card" data-href="<?php echo e(route('product.show', $item->id)); ?>" data-rating="<?php echo e($item->rating); ?>" data-reviews="<?php echo e($item->review_count); ?>">
                <img src="<?php echo e($image ? asset($image->image_path) : asset('image/duck.png')); ?>" alt="<?php echo e($item->name); ?>" class="product-image">
                <div class="product-rating" aria-label="Rated <?php echo e($item->rating); ?> out of 5 stars">
                    <div class="stars" aria-hidden="true">
                        <div class="stars-base">★★★★★</div>
                        <div class="stars-fill" style="width: <?php echo e(($item->rating / 5) * 100); ?>%">★★★★★</div>
                    </div>
                    <p class="rating-text">
                        <span class="rating-number"><?php echo e(number_format($item->rating, 1, ',', ' ')); ?></span>
                        <span class="rating-count"><?php echo e($item->review_count); ?>x</span>
                    </p>
                </div>
                <h3 class="product-title"><?php echo e($item->name); ?></h3>
                <p class="product-price"><?php echo e(number_format($item->price, 2, ',', ' ')); ?>€</p>
                <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($item->id); ?>">
                    <input type="hidden" name="quantity" value="1">
                    <button class="add-to-cart" type="submit" aria-label="Add product to cart">
                        <svg class="cart-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="18" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h7.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                        <span>Add to cart</span>
                    </button>
                </form>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

  </div>
</section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/product.blade.php ENDPATH**/ ?>