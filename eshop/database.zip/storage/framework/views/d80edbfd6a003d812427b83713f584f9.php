<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Lucky Quacky <?php echo $__env->yieldContent('title', 'Eshop'); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/variables.css',
        'resources/css/header_footer.css',
        'resources/js/app.js',
    ]); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>

</head>
<body>

    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>

<?php if(session('success')): ?>
    <div id="toast" class="toast-notification success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('warning')): ?>
    <div id="toast" class="toast-notification warning">
        <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div id="toast" class="toast-notification error">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/layouts/app.blade.php ENDPATH**/ ?>