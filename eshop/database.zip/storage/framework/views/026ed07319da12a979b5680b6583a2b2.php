
<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/style.css',
        'resources/css/admin_style.css'
    ]); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/js/admin.js',
        'resources/js/products.js'
    ]); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', '- add-product'); ?>

<?php $__env->startSection('content'); ?>
<main class="main_product">
    <form action="<?php echo e(route('admin.product.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <section class="product_section">

        <div class="product_gallery">
            <div class="thumbnails">
                <?php $__empty_1 = true; $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="thumb-wrapper">
                        <img class="thumb <?php echo e($loop->first ? 'active' : ''); ?>" src="<?php echo e(asset($image->image_path)); ?>" alt="thumb<?php echo e($loop->iteration); ?>">
                        <input type="checkbox" name="delete_images[]" value="<?php echo e($image->id); ?>" id="del_<?php echo e($image->id); ?>" style="display:none">
                        <button type="button" class="thumb-delete" onclick="document.getElementById('del_<?php echo e($image->id); ?>').checked = true;
                            this.closest('.thumb-wrapper').style.display = 'none';">×</button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <img class="thumb active" src="<?php echo e(asset('image/duck.png')); ?>" alt="thumb1">
                <?php endif; ?>
                <div class="thumb border border-gray add-thumb" onclick="document.getElementById('newImageInput').click()">+</div>
            </div>
            <input type="file" id="newImageInput" name="images[]" hidden>
            <div class="main_product_box">
                <img id="mainImage" src="<?php echo e(asset($product->images->first()?->image_path ?? 'image/duck.png')); ?>" alt="main image">
            </div>
        </div>

        <div class="product_info">

            <label>Product name</label>
            <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $product->name)); ?>" maxlength="80">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Description</label>
            <textarea class="form-control description" name="description" maxlength="1000"><?php echo e(old('description', $product->description)); ?></textarea>

            <div class="quantity_control">
                <p>Stock:</p>
                <input type="number" class="form-control quant-control" name="quantity" value="<?php echo e(old('quantity', $product->quantity)); ?>">
            </div>
            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Price (€)</label>
            <input type="text" class="form-control" name="price" value="<?php echo e(old('price', $product->price)); ?>" maxlength="9">
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Categories</label>
            <?php $__currentLoopData = $categoryTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="fw-bold mb-1"><?php echo e($type->name); ?></p>
                <div class="d-flex flex-wrap gap-3 mb-2">
                    <?php if($type->name == 'View'): ?>
                        <select name="categories[]" class="form-select">
                            <option value="">-- Select --</option>
                            <?php $__currentLoopData = $type->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e(in_array($category->id, old('categories', $product->categories->pluck('id')->toArray())) ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php else: ?>
                        <?php $__currentLoopData = $type->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox"
                                    name="categories[]"
                                    value="<?php echo e($category->id); ?>"
                                    id="cat_<?php echo e($category->id); ?>"
                                    <?php echo e(in_array($category->id, old('categories', $product->categories->pluck('id')->toArray())) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="cat_<?php echo e($category->id); ?>">
                                    <?php echo e($category->name); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <section class="specification">

        <div class="left_spec">
            <h2>Specification</h2>

            <table class="spec-table">
                <tr>
                    <td><input type="text" class="form-control" value="Material" disabled></td>
                    <td><input type="text" class="form-control" name="material" value="<?php echo e(old('material', $product->material)); ?>" maxlength="100"></td>
                </tr>
                <?php $__errorArgs = ['material'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <tr><td colspan="2"><small class="text-danger"><?php echo e($message); ?></small></td></tr> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <tr>
                    <td><input type="text" class="form-control" value="Size" disabled></td>
                    <td><input type="text" class="form-control" name="size" value="<?php echo e(old('size', $product->size)); ?>" maxlength="50"></td>
                </tr>
                <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <tr><td colspan="2"><small class="text-danger"><?php echo e($message); ?></small></td></tr> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <tr>
                    <td><input type="text" class="form-control" value="Weight" disabled></td>
                    <td><input type="text" class="form-control" name="weight" value="<?php echo e(old('weight', $product->weight)); ?>" maxlength="30"></td>
                </tr>
                <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <tr><td colspan="2"><small class="text-danger"><?php echo e($message); ?></small></td></tr> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <tr>
                    <td><input type="text" class="form-control" value="Age" disabled></td>
                    <td><input type="text" class="form-control" name="age" value="<?php echo e(old('age', $product->age)); ?>" maxlength="30"></td>
                </tr>
                <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <tr><td colspan="2"><small class="text-danger"><?php echo e($message); ?></small></td></tr> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <tr>
                    <td><input type="text" class="form-control" value="Country of origin" disabled></td>
                    <td><input type="text" class="form-control" name="country_of_origin" value="<?php echo e(old('country_of_origin', $product->country_of_origin)); ?>" maxlength="60"></td>
                </tr>
                <?php $__errorArgs = ['country_of_origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <tr><td colspan="2"><small class="text-danger"><?php echo e($message); ?></small></td></tr> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </table>
        </div>

        <div class="right_spec">
            <h2>Customer Review</h2>
            <p class="text-muted small">How would you rate this product?</p>

            <section class="review-form">
                <div class="star-rating-admin mb-3">
                    <label for="stars">★★★★★</label>
                </div>
            </section>

        </div>

    </section>

    <button class="btn btn-success w-100 mt-3 mb-3">Save changes</button>

    </form>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/admin-edit-product.blade.php ENDPATH**/ ?>