<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/user_style.css'
    ]); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', '- My Account'); ?>

<?php $__env->startSection('content'); ?>
    <main class="container py-4">

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                Please check the form and try again.
            </div>
        <?php endif; ?>

        <form class="row justify-content-center g-3" action="<?php echo e(route('account.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="col-12 col-md-6 col-lg-4">
                <div class="p-4 h-100 bg-light border rounded">

                    <h2 class="h4 mb-3">Account details</h2>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control bg-light" value="<?php echo e($userInfo->email_address ?? ''); ?>" disabled>
                    </div>

                    <div class="mb-3">
                        <label for="first-name" class="form-label">First Name</label>
                        <input id="first-name" name="first_name" type="text" class="form-control"
                            value="<?php echo e(old('first_name', $userInfo->first_name ?? '')); ?>" maxlength="50">
                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="last-name" class="form-label">Last Name</label>
                        <input id="last-name" name="last_name" type="text" class="form-control"
                            value="<?php echo e(old('last_name', $userInfo->last_name ?? '')); ?>" maxlength="50">
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="phone-number" class="form-label">Phone Number</label>
                        <input id="phone-number" name="phone_number" type="text" class="form-control"
                            value="<?php echo e(old('phone_number', $userInfo->phone_number ?? '')); ?>" maxlength="20">
                        <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-4">
                <div class="p-4 h-100 d-flex flex-column bg-light border rounded">

                    <h2 class="h4 mb-3">Address details</h2>

                    <div class="mb-3">
                        <label for="country" class="form-label">Country</label>
                        <input id="country" name="state" type="text" class="form-control"
                            value="<?php echo e(old('street', $address->state ?? '')); ?>" maxlength="40">
                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="street-address" class="form-label">Street Address</label>
                        <input id="street-address" name="street" type="text" class="form-control"
                            value="<?php echo e(old('street', $address->street ?? '')); ?>" maxlength="50">
                        <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="street-number" class="form-label">Street Number</label>
                        <input id="street-number" name="house_number" type="text" class="form-control"
                            value="<?php echo e(old('house_number', $address->house_number ?? '')); ?>" maxlength="10">
                        <?php $__errorArgs = ['house_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="city" class="form-label">City</label>
                        <input id="city" name="city" type="text" class="form-control"
                            value="<?php echo e(old('city', $address->city ?? '')); ?>" maxlength="40">
                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="postal-code" class="form-label">Postal Code</label>
                        <input id="postal-code" name="postal_code" type="text" class="form-control"
                            value="<?php echo e(old('postal_code', $address->postal_code ?? '')); ?>" maxlength="10">
                        <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn btn-warning w-100 mt-auto">
                        Save changes
                    </button>

                </div>
            </div>

        </form>

        <div class="row justify-content-center g-3 mt-1">
            <div class="col-12 col-md-6 col-lg-4 offset-lg-4">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-dark w-100">
                        Logout
                    </button>
                </form>
            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kavon\Desktop\WTECH\projekt_eshop\eshop\resources\views/user-account.blade.php ENDPATH**/ ?>